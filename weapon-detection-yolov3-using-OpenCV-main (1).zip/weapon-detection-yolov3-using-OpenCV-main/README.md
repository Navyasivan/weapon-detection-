# weapon-detection-yolov3-using-OpenCV

Download pretrain [Weights](https://drive.google.com/file/d/14gFCIwE8ChFtihc45KJeyKndmZs29k7l/view?usp=drivesdk) here
